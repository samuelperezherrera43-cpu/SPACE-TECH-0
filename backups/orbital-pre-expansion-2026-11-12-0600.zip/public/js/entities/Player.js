import * as THREE from 'three';
import { GROUP } from '../engine/Physics.js';

const _forward = new THREE.Vector3();
const _right = new THREE.Vector3();
const _wish = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _nozzle = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _upAlt = new THREE.Vector3(1, 0, 0);

/**
 * Astronauta: cuerpo esférico en cannon-es + malla low-poly procedural.
 * Movimiento 6DOF relativo a la cámara, con propulsores RCS, O2 y energía.
 */
export class Player {
  constructor(scene, physics, particles, materials, balance) {
    this.physics = physics;
    this.particles = particles;
    this.materials = materials;
    this.balance = balance;
    this.radius = 0.45;

    this.energy = 100;
    this.o2 = 100;
    this.hull = 100;
    this.speed = 0;
    this.thrusting = false;
    this.dead = false;
    this.regenDelay = 0;
    this.safe = false;
    this.o2RegenScale = 1;
    this.lastImpact = -10;
    this.onDamage = null;

    this.thrustDir = new THREE.Vector3(0, 0, -1);
    this.facing = new THREE.Vector3(0, 0, 1);
    this.thrusterAccum = 0;
    this.time = 0;
    this.inside = false;

    this.body = physics.sphere([0, 2, 18], this.radius, 80, {
      fixedRotation: true,
      linearDamping: 0.1,
      angularDamping: 1,
      allowSleep: false,
      collisionFilterGroup: GROUP.PLAYER,
      collisionFilterMask: GROUP.STATION,
    });

    this.body.addEventListener('collide', (event) => this._onCollide(event));

    this.group = new THREE.Group();
    this.group.add(this._buildMesh());

    // Punto de anclaje de la herramienta (mano derecha, mirando a +Z).
    this.hand = new THREE.Group();
    this.hand.position.set(0.44, -0.18, 0.1);
    this.hand.rotation.set(-0.12, 0.32, 0.1);
    this.group.add(this.hand);

    this.dummy = new THREE.Object3D();
    scene.add(this.group);

    this.reset();
  }

  get position() {
    return this.group.position;
  }

  /* --------------------------------------------------------------- impactos */

  _onCollide(event) {
    const contact = event.contact;
    if (!contact) return;

    let impact = 0;
    try {
      impact = Math.abs(contact.getImpactVelocityAlongNormal());
    } catch {
      return;
    }

    const config = this.balance?.values;
    const threshold = config?.hullImpactThreshold ?? 3.2;
    if (impact < threshold) return;
    if (this.time - this.lastImpact < 0.75) return;

    this.lastImpact = this.time;
    const scale = (config?.hullImpactScale ?? 1) * (this.safe ? 0.25 : 1);
    const damage = Math.min(22, (impact - threshold) * 2.2 * scale);
    if (damage < 0.4) return;

    this.hull = Math.max(0, this.hull - damage);
    this.onDamage?.(damage, impact);
  }

  applyDamage(amount) {
    this.hull = Math.max(0, this.hull - Math.max(0, amount));
    if (this.hull <= 0) this.dead = true;
  }

  repairHull(amount) {
    this.hull = Math.min(100, this.hull + Math.max(0, amount));
  }

  /* ------------------------------------------------------------------ malla */

  _buildMesh() {
    const root = new THREE.Group();

    if (!this.materials) {
      throw new Error('Player requiere una MaterialLibrary');
    }

    const suit = this.materials.suit;
    const dark = this.materials.suitDark;
    const visor = this.materials.visor;
    const accent = this.materials.accent;

    // Sombra selectiva: solo las piezas que definen la silueta proyectan.
    const shadow = (mesh, cast = true) => {
      mesh.castShadow = cast;
      mesh.receiveShadow = true;
      return mesh;
    };

    // Torso
    const torso = shadow(new THREE.Mesh(new THREE.CapsuleGeometry(0.26, 0.44, 4, 10), suit));
    torso.position.y = 0.02;
    root.add(torso);

    // Arnés / pecho
    const chest = shadow(new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.2, 0.1), dark));
    chest.position.set(0, 0.1, 0.22);
    root.add(chest);

    const chestLight = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.03, 0.02), accent);
    chestLight.position.set(0, 0.13, 0.28);
    root.add(chestLight);

    // Casco + visor
    const helmet = shadow(new THREE.Mesh(new THREE.SphereGeometry(0.29, 14, 11), suit));
    helmet.position.y = 0.56;
    root.add(helmet);

    const visorMesh = new THREE.Mesh(new THREE.SphereGeometry(0.255, 14, 11), visor);
    visorMesh.scale.set(1, 0.82, 0.6);
    visorMesh.position.set(0, 0.56, 0.12);
    root.add(visorMesh);

    // Mochila y tanques
    const pack = shadow(new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.54, 0.24), dark));
    pack.position.set(0, 0.04, -0.32);
    root.add(pack);

    const tankGeo = new THREE.CylinderGeometry(0.075, 0.075, 0.42, 8);
    for (const x of [-0.15, 0.15]) {
      const tank = shadow(new THREE.Mesh(tankGeo, suit), false);
      tank.position.set(x, 0.04, -0.46);
      root.add(tank);
    }

    // Brazos
    const armGeo = new THREE.CapsuleGeometry(0.075, 0.32, 4, 8);
    for (const side of [-1, 1]) {
      const arm = shadow(new THREE.Mesh(armGeo, suit), false);
      arm.position.set(side * 0.37, 0.02, 0.02);
      arm.rotation.z = side * 0.14;
      root.add(arm);

      const glove = shadow(new THREE.Mesh(new THREE.SphereGeometry(0.095, 8, 7), dark), false);
      glove.position.set(side * 0.4, -0.2, 0.06);
      root.add(glove);
    }

    // Piernas
    const legGeo = new THREE.CapsuleGeometry(0.095, 0.4, 4, 8);
    for (const side of [-1, 1]) {
      const leg = shadow(new THREE.Mesh(legGeo, suit), false);
      leg.position.set(side * 0.14, -0.52, 0);
      leg.rotation.z = side * 0.04;
      root.add(leg);

      const boot = shadow(new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.13, 0.26), dark), false);
      boot.position.set(side * 0.14, -0.8, 0.05);
      root.add(boot);
    }

    // Antena
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.3, 4), dark);
    antenna.position.set(0.19, 0.76, -0.1);
    antenna.rotation.z = -0.18;
    root.add(antenna);

    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.022, 6, 5), accent);
    beacon.position.set(0.22, 0.9, -0.1);
    root.add(beacon);

    return root;
  }

  /* ----------------------------------------------------------------- estado */

  reset() {
    this.body.position.set(0, 2, 18);
    this.body.velocity.setZero();
    this.body.angularVelocity.setZero();
    this.body.force.setZero();
    this.body.torque.setZero();

    this.energy = 100;
    this.o2 = 100;
    this.hull = 100;
    this.speed = 0;
    this.thrusting = false;
    this.dead = false;
    this.regenDelay = 0;
    this.safe = false;
    this.o2RegenScale = 1;
    this.lastImpact = -10;
    this.facing.set(0, 0, 1);
    this.thrustDir.set(0, 0, -1);

    this.group.position.set(0, 2, 18);
    this.group.quaternion.identity();
    this.group.rotation.y = Math.PI;
    this.facing.set(0, 0, -1);
    this.setInterior(false);
  }

  /**
   * Cambia la capa de iluminación: fuera (0, sol) / dentro (1, luces del
   * interior). Evita que el sol atraviese las paredes de los módulos.
   */
  setInterior(inside) {
    if (this.inside === inside) return;
    this.inside = inside;
    const layer = inside ? 1 : 0;
    this.group.traverse((object) => object.layers.set(layer));
  }

  setSafe(safe) {
    this.safe = safe;
  }

  /** Aplica fuerzas y consume recursos. Llamar antes de physics.step(). */
  update(dt, input, camera, boost) {
    this.time += dt;

    _wish.set(0, 0, 0);

    if (input.z) {
      camera.getWorldDirection(_forward);
      _wish.addScaledVector(_forward, input.z);
    }
    if (input.x) {
      _right.setFromMatrixColumn(camera.matrixWorld, 0).normalize();
      _wish.addScaledVector(_right, input.x);
    }
    if (input.y) _wish.y += input.y;

    const wantsThrust = _wish.lengthSq() > 1e-4 && this.energy > 0.5;
    this.thrusting = wantsThrust;

    if (wantsThrust) {
      _wish.normalize();
      this.thrustDir.copy(_wish);

      const acceleration = boost ? 30 : 17;
      const force = this.body.mass * acceleration;
      this.body.applyForce(
        new THREE.Vector3(_wish.x * force, _wish.y * force, _wish.z * force)
      );
    }

    // Límite de velocidad arcade: sin gravedad, evita que la partida se descontrole.
    const velocity = this.body.velocity;
    const speed = Math.sqrt(velocity.x ** 2 + velocity.y ** 2 + velocity.z ** 2);
    const maxSpeed = boost ? 22 : 13;

    if (speed > maxSpeed) {
      const scale = maxSpeed / speed;
      velocity.x *= scale;
      velocity.y *= scale;
      velocity.z *= scale;
    }
    this.speed = Math.min(speed, maxSpeed);

    // Frontera suave de la zona de misión.
    const p = this.body.position;
    const distance = Math.sqrt(p.x ** 2 + p.y ** 2 + p.z ** 2);
    if (distance > 150) {
      const pull = (distance - 150) * this.body.mass * 1.6;
      this.body.applyForce(new THREE.Vector3((-p.x / distance) * pull, (-p.y / distance) * pull, (-p.z / distance) * pull));
    }

    const config = this.balance?.values ?? {
      o2Drain: 0.42,
      o2ThrustDrain: 0.16,
      o2Regen: 10,
      rcsDrain: 2.4,
      rcsBoostDrain: 3.8,
      rcsRegen: 12,
    };

    // RCS: sólo consume mientras se aplica impulso. En el exterior no se
    // regenera; al volver a una zona presurizada se recarga.
    if (this.thrusting) {
      const drain = boost ? config.rcsBoostDrain : config.rcsDrain;
      this.energy = Math.max(0, this.energy - drain * dt);
      this.regenDelay = 0.8;
    } else {
      this.regenDelay = Math.max(0, this.regenDelay - dt);
      if (this.safe) {
        this.energy = Math.min(100, this.energy + config.rcsRegen * dt);
      }
    }

    // Oxígeno: sólo se consume durante una EVA. Dentro del hábitat o en una
    // esclusa presurizada se recupera.
    if (this.safe) {
      this.o2 = Math.min(100, this.o2 + config.o2Regen * this.o2RegenScale * dt);
    } else {
      let drain = config.o2Drain;
      if (this.thrusting) drain += config.o2ThrustDrain;
      this.o2 = Math.max(0, this.o2 - drain * dt);
    }

    if (this.o2 <= 0 || this.hull <= 0) this.dead = true;
  }

  /** Sincroniza malla, orientación y partículas. Llamar tras physics.step(). */
  sync(dt, camera) {
    const p = this.body.position;
    this.group.position.set(p.x, p.y, p.z);

    // Orientación: mira hacia el movimiento; en reposo, hacia la cámara.
    if (this.speed > 0.6) {
      _dir.set(this.body.velocity.x, this.body.velocity.y, this.body.velocity.z).normalize();
      this.facing.lerp(_dir, 1 - Math.exp(-dt * 5)).normalize();
    } else {
      camera.getWorldDirection(_dir);
      _dir.y *= 0.5;
      if (_dir.lengthSq() > 0.001) {
        _dir.normalize();
        this.facing.lerp(_dir, 1 - Math.exp(-dt * 2.2)).normalize();
      }
    }

    const up = Math.abs(this.facing.y) > 0.985 ? _upAlt : _up;
    this.dummy.position.copy(this.group.position);
    this.dummy.up.copy(up);
    this.dummy.lookAt(
      this.group.position.x + this.facing.x,
      this.group.position.y + this.facing.y,
      this.group.position.z + this.facing.z
    );
    this.group.quaternion.slerp(this.dummy.quaternion, 1 - Math.exp(-dt * 7));

    // Escape de los propulsores (dos toberas de la mochila).
    if (this.thrusting && this.particles) {
      this.thrusterAccum += dt;
      const exhaust = _dir.copy(this.thrustDir).negate();

      while (this.thrusterAccum > 0.028) {
        this.thrusterAccum -= 0.028;

        for (const side of [-1, 1]) {
          _nozzle.set(side * 0.17, 0.02, -0.5)
            .applyQuaternion(this.group.quaternion)
            .add(this.group.position);

          this.particles.spawn(_nozzle, exhaust, {
            speed: 4.5,
            spread: 0.55,
            life: 0.35,
            offset: 0.06,
          });
        }
      }
    } else {
      this.thrusterAccum = 0;
    }
  }
}
