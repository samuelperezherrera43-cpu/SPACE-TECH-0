/**
 * Presets gráficos. "high" prioriza materiales, sombras y bloom;
 * "performance" reduce resolución, sombras y postprocesado.
 */
export const QUALITY_PRESETS = {
  high: {
    id: 'high',
    name: 'Alta',
    pixelRatio: 1.25,
    shadows: true,
    shadowMapSize: 1024,
    bloom: true,
    bloomStrength: 0.32,
    bloomRadius: 0.45,
    bloomThreshold: 0.82,
    bloomResolutionScale: 0.5,
    aa: 'smaa',
    anisotropy: 8,
    stars: 2400,
    pointLights: true,
  },
  performance: {
    id: 'performance',
    name: 'Rendimiento',
    pixelRatio: 1,
    shadows: false,
    shadowMapSize: 512,
    bloom: false,
    bloomStrength: 0,
    bloomRadius: 0.4,
    bloomThreshold: 0.9,
    aa: 'none',
    anisotropy: 2,
    stars: 1200,
    pointLights: false,
  },
};

const STORAGE_KEY = 'orbital.quality.v1';

export class QualityManager {
  constructor() {
    this.presets = QUALITY_PRESETS;
    this.current = this._load() || this._detect();
    this.onChange = null;
  }

  get preset() {
    return this.presets[this.current] ?? this.presets.high;
  }

  set(name) {
    if (!this.presets[name] || name === this.current) return this.preset;
    this.current = name;
    try {
      localStorage.setItem(STORAGE_KEY, name);
    } catch {
      // localStorage puede estar bloqueado; el preset sigue activo en memoria.
    }
    this.onChange?.(this.preset, name);
    return this.preset;
  }

  _load() {
    try {
      const value = localStorage.getItem(STORAGE_KEY);
      return value && this.presets[value] ? value : null;
    } catch {
      return null;
    }
  }

  _detect() {
    const coarse = window.matchMedia?.('(pointer: coarse)').matches ?? false;
    const cores = navigator.hardwareConcurrency ?? 8;
    const memory = navigator.deviceMemory ?? 8;
    const small = window.innerWidth < 900;
    return coarse || cores <= 4 || memory <= 4 || small ? 'performance' : 'high';
  }
}
