import * as THREE from 'three';
import { Physics } from '../engine/Physics.js';
import { Controls } from '../engine/Controls.js';
import { ThirdPersonCamera } from '../engine/Camera.js';
import { AudioEngine } from '../engine/Audio.js';
import { ParticleSystem } from '../engine/Particles.js';
import { QualityManager } from '../engine/Quality.js';
import { MaterialLibrary } from '../engine/Materials.js';
import { Environment } from '../engine/Environment.js';
import { PostFX } from '../engine/PostFX.js';
import { Interior } from '../engine/Interior.js';
import { InteriorInteractions } from '../engine/InteriorInteractions.js';
import { Player } from '../entities/Player.js';
import { Station } from '../entities/Station.js';
import { ToolRig, TOOLS } from '../entities/Tool.js';
import { Tether } from '../entities/Tether.js';
import { ExteriorTasks } from '../entities/ExteriorTasks.js';
import { HUD } from '../ui/HUD.js';
import { BalanceManager } from './Balance.js';
import { MissionManager, MISSION_CATEGORIES } from './Missions.js';

const CENTER = new THREE.Vector2(0, 0);
const REQUIRED_TOOL = { hull: 'SOLDADOR', valve: 'LLAVE' };

const NAV_POIS = [
  { id: 'airlock', name: 'Esclusa EVA-07', position: new THREE.Vector3(0, -9, 6.0) },
  { id: 'solar', name: 'Matriz solar este', position: new THREE.Vector3(12, 0, 0) },
  { id: 'antenna', name: 'Antena de banda X', position: new THREE.Vector3(0, 6.5, 0) },
  { id: 'lab', name: 'Laboratorio', position: new THREE.Vector3(-5, -9, -1.5) },
  { id: 'storage', name: 'Almacén', position: new THREE.Vector3(4.5, -9, -6.25) },
  { id: 'debris', name: 'Campo de escombros', position: new THREE.Vector3(0, 4, 22) },
];

/**
 * Orquestador: estado de partida, loop, interacción, misiones, cable EVA y HUD.
 */
export class Game {
  constructor(root) {
    this.root = root;
    this.canvas = root.querySelector('#scene');

    // Calidad antes que el renderer: define resolución, sombras y postproceso.
    this.quality = new QualityManager();
    const preset = this.quality.preset;

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: false,
      stencil: false,
      powerPreference: 'high-performance',
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, preset.pixelRatio));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.02;
    this.renderer.shadowMap.enabled = !!preset.shadows;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    // Las draw calls se acumulan por frame; el composer hace varias pasadas.
    this.renderer.info.autoReset = false;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x04060d);
    this.scene.fog = new THREE.FogExp2(0x04060d, 0.0014);

    this.camera = new THREE.PerspectiveCamera(
      62,
      window.innerWidth / window.innerHeight,
      0.1,
      1400
    );
    // Capa 0: exterior (sol). Capa 1: interior (luces propias).
    this.camera.layers.enable(1);

    this.clock = new THREE.Clock();
    this.state = 'menu';
    this.hadLock = false;
    this.ignoreUnlock = false;
    this.time = 0;
    this.integrity = 100;
    this.toolIndex = 0;
    this.repairing = false;
    this.revealUntil = 0;
    this.scanCooldown = 0;
    this.alarmTimer = 0;
    this.sparkAccum = 0;
    this.center = CENTER;
    this.raycaster = new THREE.Raycaster();
    this.needsRender = true;

    this.panelOpen = null;
    this.panelSource = null;
    this.job = null;
    this.seated = false;
    this.navTarget = null;
    this.visitedPois = new Set();
    this.commsSent = false;
    this.repairCooldown = 0;
    this.lastDamageToast = 0;
    this.scienceData = 0;

    this.inventory = { component: 0, filter: 0, sample: 0, tools: 0 };
    this.engineering = { circuits: [false, false, false] };
    this.lifeSupport = { filters: [false, false] };
    this.lab = { samples: [false, false, false], calibrated: false };

    this.balance = new BalanceManager();
    this.balance.onChange = (values, id) => {
      this.tether?.setConfig(values);
      this._syncDifficultyUI();
      this.hud.toast(`Dificultad: ${values.name}`, 'good', 2.4);
      void id;
    };

    this.hud = new HUD(root);
    this.audio = new AudioEngine();
    this.physics = new Physics();

    // Materiales y entorno compartidos (texturas procedurales PBR).
    this.materials = new MaterialLibrary(this.renderer, preset);
    this.environment = new Environment(this.scene, this.renderer, preset);
    this.postFX = new PostFX(this.renderer, this.scene, this.camera, preset);

    // Partículas: propulsores, chispas de soldadura y fugas de aire.
    const particleRatio = this.renderer.getPixelRatio();
    this.thrusterParticles = new ParticleSystem(this.scene, {
      count: 260, color: 0xbfefff, size: 0.09, drag: 2.4, pixelRatio: particleRatio,
    });
    this.sparkParticles = new ParticleSystem(this.scene, {
      count: 200, color: 0xffb060, size: 0.075, drag: 1.1, pixelRatio: particleRatio,
    });
    this.leakParticles = new ParticleSystem(this.scene, {
      count: 220, color: 0xdff6ff, size: 0.11, drag: 1.6, opacity: 0.55, pixelRatio: particleRatio,
    });

    this.station = new Station(this.scene, this.physics, this.leakParticles, this.materials);
    this.player = new Player(
      this.scene,
      this.physics,
      this.thrusterParticles,
      this.materials,
      this.balance
    );
    this.toolRig = new ToolRig(this.player.hand, this.materials);

    this.player.onDamage = (damage, impact) => {
      if (this.time - this.lastDamageToast < 1.2) return;
      this.lastDamageToast = this.time;
      this.cameraRig?.addShake(Math.min(0.22, damage * 0.012));
      this.hud.toast(
        `Impacto · casco -${Math.round(damage)}% (${impact.toFixed(1)} m/s)`,
        'bad',
        2.2
      );
    };

    // Interior habitable: GLB optimizados + colisiones + esclusa.
    this.interior = new Interior(this.scene, this.physics, this.materials, preset);
    this.interior.onEvent = (type) => this._onInteriorEvent(type);

    // Consolas interiores y tareas exteriores.
    this.interiorSystems = new InteriorInteractions(this.scene, this.materials);
    this.exteriorTasks = new ExteriorTasks(this.scene, this.materials);

    // Misiones: una activa a la vez.
    this.missions = new MissionManager();
    this.missions.onComplete = (mission) => this._onMissionComplete(mission);

    // Cable de seguridad: anclado a la esclusa, activo en EVA.
    this.tether = new Tether(this.scene, this.player, this.balance.values);

    this.cameraRig = new ThirdPersonCamera(this.camera);
    this.cameraRig.occluders = this.station.occluders;
    this.interior.ready.then(() => {
      this.cameraRig.occluders.push(...this.interior.occluders);
    });

    this.controls = new Controls(this.canvas);
    this._bindEvents();
    this._syncQualityUI();
    this._syncDifficultyUI();

    this.quality.onChange = (nextPreset) => this.applyQuality(nextPreset);

    this.hud.setTool(0);
    this.hud.setStats(100, 100, 100);
    this.hud.setMission(this.missions.active);
    this.hud.setTether({ active: false, distance: 0, max: this.tether.max, tension: 0 });
    this.hud.setPressure(this.interior.getAirlockStatus());
    this.hud.setWarnings([]);
    this.hud.screen('start');
    this.cameraRig.updateMenu(0);
  }

  /* ---------------------------------------------------------------- calidad */

  /** Aplica un preset sin recrear la escena. */
  applyQuality(preset) {
    const ratio = Math.min(window.devicePixelRatio || 1, preset.pixelRatio);

    this.renderer.setPixelRatio(ratio);
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.shadowMap.enabled = !!preset.shadows;

    this.materials.setQuality(preset);
    this.environment.setQuality(preset);
    this.postFX.setQuality(preset);
    this.interior.setQuality(preset);

    this.thrusterParticles.setPixelRatio(ratio);
    this.sparkParticles.setPixelRatio(ratio);
    this.leakParticles.setPixelRatio(ratio);

    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();

    this._syncQualityUI();
    this.needsRender = true;
  }

  _syncQualityUI() {
    const buttons = this.root.querySelectorAll('[data-quality]');
    for (const button of buttons) {
      const active = button.dataset.quality === this.quality.current;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    }
  }

  _syncDifficultyUI() {
    const buttons = this.root.querySelectorAll('[data-difficulty]');
    for (const button of buttons) {
      const active = button.dataset.difficulty === this.balance.id;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-pressed', String(active));
    }
  }

  /* --------------------------------------------------------------- eventos */

  _bindEvents() {
    window.addEventListener('resize', () => {
      this.camera.aspect = window.innerWidth / window.innerHeight;
      this.camera.updateProjectionMatrix();
      this.renderer.setPixelRatio(
        Math.min(window.devicePixelRatio || 1, this.quality.preset.pixelRatio)
      );
      this.renderer.setSize(window.innerWidth, window.innerHeight, false);
      this.postFX.setSize(window.innerWidth, window.innerHeight);
      this.environment.setPixelRatio(this.renderer.getPixelRatio());
      const ratio = this.renderer.getPixelRatio();
      this.thrusterParticles.setPixelRatio(ratio);
      this.sparkParticles.setPixelRatio(ratio);
      this.leakParticles.setPixelRatio(ratio);
      this.needsRender = true;
    });

    for (const button of this.root.querySelectorAll('[data-quality]')) {
      button.addEventListener('click', () => this.quality.set(button.dataset.quality));
    }

    for (const button of this.root.querySelectorAll('[data-difficulty]')) {
      button.addEventListener('click', () => this.balance.set(button.dataset.difficulty));
    }

    this.controls.onTool = (index) => this.selectTool(index);

    this.controls.onLockChange = (locked) => {
      if (locked) {
        this.hadLock = true;
        this.ignoreUnlock = false;
        return;
      }
      if (this.panelOpen) return;
      if (!this.hadLock) return;
      if (this.ignoreUnlock) {
        this.ignoreUnlock = false;
        return;
      }
      if (this.state === 'playing') this.pause();
    };

    this.root.querySelector('#btn-start').addEventListener('click', () => this.start());
    this.root.querySelector('#btn-resume').addEventListener('click', () => this.resume());
    this.root.querySelector('#btn-restart-pause').addEventListener('click', () => this.start());
    this.root.querySelector('#btn-restart-win').addEventListener('click', () => this.start());
    this.root.querySelector('#btn-restart-lose').addEventListener('click', () => this.start());
    this.root.querySelector('#panel-close').addEventListener('click', () => this.closePanel());
    this.root.querySelector('#panel-body').addEventListener('click', (event) => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      this.handlePanelAction(button.dataset.action, button.dataset.id);
    });

    window.addEventListener('keydown', (event) => {
      if (event.code === 'Enter' && this.state === 'menu') this.start();
      if (event.code === 'Escape' && this.panelOpen) {
        event.preventDefault();
        this.closePanel();
      }
    });

    document.addEventListener('visibilitychange', () => {
      if (document.hidden && this.state === 'playing') this.pause();
    });
  }

  _onInteriorEvent(type) {
    const messages = {
      airlockOpen: 'Esclusa: compuerta en movimiento',
      pressurizing: 'Esclusa: presurizando...',
      pressurized: 'Esclusa presurizada · a bordo',
      depressurizing: 'Esclusa: despresurizando...',
      depressurized: 'Esclusa despresurizada · al exterior',
      entered: 'A bordo · oxígeno recuperándose',
      exited: 'EVA · cable de seguridad conectado',
    };
    if (messages[type]) this.hud.toast(messages[type], 'good', 2.6);
    if (type === 'entered' || type === 'exited') this.audio.ui();
  }

  /* ----------------------------------------------------------------- ciclo */

  run() {
    this.renderer.setAnimationLoop(() => this.frame());
  }

  frame() {
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.renderer.info.reset();
    this.environment.update(dt);

    if (this.state === 'playing') {
      this.update(dt);
      this.postFX.render(dt);
    } else if (this.state === 'menu') {
      this.cameraRig.updateMenu(dt);
      this.station.update(dt);
      this.interior.update(dt, this.player.group.position);
      this.interiorSystems.update(dt, this.player.group.position);
      this.exteriorTasks.update(dt, this.player.group.position, this.missions.activeId);
      this.leakParticles.update(dt);
      this.postFX.render(dt);
    } else if (this.needsRender) {
      // Pausa / victoria / derrota: congelar el render ahorra GPU.
      this.needsRender = false;
      this.postFX.render(dt);
    }
  }

  update(dt) {
    this.time += dt;
    this.updateJobs(dt);

    if (this.panelOpen) {
      this.interior.update(dt, this.player.group.position);
      this.station.update(dt);
      this.interiorSystems.update(dt, this.player.group.position);
      this.exteriorTasks.update(dt, this.player.group.position, this.missions.activeId);
      this.tether.updateVisual(false);
      if (this.seated) this.cameraRig.updateSeated(dt);
      this.updateHUD();
      return;
    }

    this.controls.poll();

    const mouse = this.controls.consumeMouse();
    if (mouse.dx || mouse.dy) this.cameraRig.rotate(mouse.dx, mouse.dy);

    const wheel = this.controls.consumeWheel();
    if (wheel) this.cameraRig.zoom(wheel);

    const position = this.player.group.position;
    const inside = this.interior.contains(position);
    const safe = this.interior.isSafe(position);

    this.player.setInterior(inside);
    this.player.setSafe(safe);
    this.environment.setInterior(inside);
    this.cameraRig.inside = inside;
    this.cameraRig.floor = this.interior.floor;
    this.cameraRig.ceil = this.interior.ceil;

    // Física
    this.player.update(dt, this.controls.move, this.camera, this.controls.boost);
    this.tether.applyPhysics(dt, !safe);
    this.physics.step(dt);
    this.player.sync(dt, this.camera);
    this.tether.updateVisual(!safe);

    this.cameraRig.update(dt, this.player.group.position);

    this.station.update(dt);
    this.interior.update(dt, this.player.group.position);
    this.interiorSystems.update(dt, this.player.group.position);
    this.exteriorTasks.update(dt, this.player.group.position, this.missions.activeId);

    this.updateInteraction(dt);
    this.updateMission(dt);

    if (this.state !== 'playing') return;

    this.thrusterParticles.update(dt);
    this.sparkParticles.update(dt);
    this.leakParticles.update(dt);

    this.toolRig.update(dt, this.player.speed, this.repairing);
    this.updateAudio();
    this.updateHUD();
  }

  /* ------------------------------------------------------------ interacción */

  findTarget() {
    if (this.station.active.length === 0) return null;

    this.raycaster.setFromCamera(this.center, this.camera);
    this.raycaster.far = 80;
    this.raycaster.near = 0;

    const hits = this.raycaster.intersectObjects(this.station.hitMeshes, false);
    const playerPosition = this.player.group.position;

    for (const hit of hits) {
      const breach = hit.object.userData.breach;
      if (!breach || !breach.active) continue;
      if (breach.position.distanceTo(playerPosition) > 5.5) continue;
      return breach;
    }

    return null;
  }

  updateInteraction(dt) {
    const tool = TOOLS[this.toolIndex];
    const clicked = this.controls.consumeClick();
    const interact = this.controls.consumeInteract();
    const held = this.controls.interactHeld;
    const position = this.player.group.position;
    this.repairing = false;

    // 1. Esclusa: siempre tiene prioridad.
    const airlockAction = this.interior.getAirlockAction(position);
    if (airlockAction) {
      this.hud.setCrosshair('none');
      this.hud.showPrompt(airlockAction.label, airlockAction.key, 1);
      if (interact) {
        if (this.interior.requestAirlock(position)) this.audio.ui();
      }
      return;
    }

    // 2. Interior: consolas y puestos de mando.
    if (this.player.inside) {
      this.hud.setCrosshair('none');
      const point = this.interiorSystems.getNearby(position);
      if (point) {
        this.hud.showPrompt(point.label, 'E', 1);
        if (interact) this.openInteriorPoint(point);
      } else {
        this.hud.hidePrompt();
      }
      return;
    }

    // 3. Tareas EVA de la misión activa.
    const task = this.exteriorTasks.getNearby(position);
    if (task) {
      this.updateExteriorTask(task, interact, held, dt);
      return;
    }

    const nearPort = this.updateOxygenPort(dt);

    // Escáner: utilidad, no repara.
    if (!tool.repairs) {
      this.hud.setCrosshair('none');

      if (this.scanCooldown > 0) {
        if (!nearPort) {
          this.hud.showPrompt(
            'Escáner recargando',
            `LISTO EN ${this.scanCooldown.toFixed(1)}s`,
            1 - this.scanCooldown / this.balance.values.scanCooldown
          );
        }
      } else if (!nearPort) {
        this.hud.showPrompt(
          `Escanear fugas activas (${this.station.active.length})`,
          'CLIC IZQ',
          1
        );
      }

      if (clicked && this.scanCooldown <= 0) this.scan();
      return;
    }

    const target = this.findTarget();

    if (!target) {
      this.hud.setCrosshair('none');
      if (!nearPort) this.hud.hidePrompt();
      return;
    }

    const correct = tool.repairs === target.type;

    if (!correct) {
      this.hud.setCrosshair('wrong');
      this.hud.showPrompt(
        `Se necesita ${REQUIRED_TOOL[target.type]}`,
        'CAMBIA DE HERRAMIENTA (1 / 2)',
        target.progress
      );
      target.progress = Math.max(0, target.progress - dt * 0.4);
      return;
    }

    this.hud.setCrosshair('target');

    if (this.controls.repairHeld) {
      this.repairing = true;
      target.progress += dt / tool.repairTime;

      this.sparkAccum += dt;
      while (this.sparkAccum > 0.045) {
        this.sparkAccum -= 0.045;
        this.sparkParticles.spawn(target.position, target.normal, {
          speed: 4.2,
          spread: 1.2,
          life: 0.5,
          offset: 0.25,
        });
      }

      if (target.progress >= 1) {
        this.completeRepair(target);
        return;
      }
    } else {
      target.progress = Math.max(0, target.progress - dt * 0.3);
    }

    this.hud.showPrompt(
      target.type === 'hull' ? 'Sellar fisura del casco' : 'Apretar válvula',
      'MANTÉN CLIC IZQ',
      target.progress
    );
  }

  updateExteriorTask(task, interact, held, dt) {
    this.hud.setCrosshair('none');

    if (task.tool != null && this.toolIndex !== task.tool) {
      this.hud.showPrompt(
        `Se necesita ${TOOLS[task.tool].name}`,
        'CAMBIA DE HERRAMIENTA (1 / 2 / 3)',
        0
      );
      return;
    }

    if (task.requires && this.inventory[task.requires] <= 0) {
      this.hud.showPrompt(
        task.requires === 'component' ? 'Falta el kit de repuesto' : 'Falta material',
        'ALMACÉN',
        0
      );
      return;
    }

    if (task.duration <= 0) {
      this.hud.showPrompt(task.label, 'E', 1);
      if (interact) this.completeExteriorTask(task);
      return;
    }

    if (held) {
      const scale = this.balance.values.repairTimeScale ?? 1;
      task.progress = Math.min(1, task.progress + dt / (task.duration * scale));

      this.sparkAccum += dt;
      while (this.sparkAccum > 0.06) {
        this.sparkAccum -= 0.06;
        this.sparkParticles.spawn(
          task.group.position,
          new THREE.Vector3(0, 1, 0),
          { speed: 3.0, spread: 0.9, life: 0.45, offset: 0.2 }
        );
      }

      if (task.progress >= 1) {
        this.completeExteriorTask(task);
        return;
      }
    } else {
      task.progress = Math.max(0, task.progress - dt * 0.9);
    }

    this.hud.showPrompt(task.label, 'MANTÉN E', task.progress);
  }

  completeExteriorTask(task) {
    const type = this.exteriorTasks.complete(task);
    if (!type) return;

    if (task.requires && this.inventory[task.requires] > 0) {
      this.inventory[task.requires] -= 1;
    }
    if (type === 'tool_pickup') this.inventory.tools += 1;

    this.missions.notify(type, 1);

    this.sparkParticles.burst(task.group.position, new THREE.Vector3(0, 1, 0), 20, {
      speed: 4.5, spread: 1.1, life: 0.6, offset: 0.2,
    });
    this.audio.success();
    this.cameraRig.addShake(0.04);
    this.hud.toast(`${task.label} · completado`, 'good', 2.4);
  }

  updateOxygenPort(dt) {
    const distance = this.station.o2Port.distanceTo(this.player.group.position);
    if (distance > 4.2) return false;

    if (this.player.o2 >= 99.5) {
      this.hud.showPrompt('Oxígeno al máximo', 'PUERTO O2', 1);
      return true;
    }

    this.player.o2 = Math.min(100, this.player.o2 + 20 * dt);
    this.hud.showPrompt('Recargando oxígeno', 'PUERTO O2', this.player.o2 / 100);
    return true;
  }

  completeRepair(breach) {
    this.station.repair(breach);
    this.player.repairHull(2);
    this.player.o2 = Math.min(100, this.player.o2 + 6);
    this.missions.notify('leaks', 1);

    this.sparkParticles.burst(breach.position, breach.normal, 26, {
      speed: 5.5, spread: 1.3, life: 0.7, offset: 0.25,
    });

    this.audio.success();
    this.cameraRig.addShake(0.06);
    this.hud.toast(`Fuga sellada · ${this.station.repairedCount} / ${this.station.totalBreaches}`, 'good');

    if (this.station.repairedCount + this.station.active.length < this.station.totalBreaches) {
      this.station.spawn();
    }

    if (this.station.repairedCount >= this.station.totalBreaches) {
      this.win();
    }
  }

  scan() {
    this.scanCooldown = this.balance.values.scanCooldown;
    this.revealUntil = this.time + 12;
    this.audio.ping();
    this.cameraRig.addShake(0.02);

    const count = this.station.active.length;
    this.hud.toast(
      count === 0
        ? 'Escaneo: sin fugas activas'
        : `Escaneo: ${count} fuga${count === 1 ? '' : 's'} detectada${count === 1 ? '' : 's'}`,
      'good',
      3
    );
  }

  /* -------------------------------------------------------------- misiones */

  updateMission(dt) {
    this.scanCooldown = Math.max(0, this.scanCooldown - dt);
    this.repairCooldown = Math.max(0, this.repairCooldown - dt);
    this.integrity = this.player.hull;

    this.alarmTimer -= dt;
    if (this.alarmTimer <= 0 && (this.player.hull < 30 || this.player.o2 < 20)) {
      this.audio.alarm();
      this.alarmTimer = 2.4;
    }

    if (this.player.hull <= 0) {
      this.lose('Casco comprometido', 'La integridad del traje llegó a cero.');
      return;
    }

    if (this.player.o2 <= 0) {
      this.lose('Sin oxígeno', 'Tu reserva de O2 se agotó en el exterior.');
    }
  }

  _onMissionComplete(mission) {
    const reward = mission.reward ?? {};
    this.player.o2 = Math.min(100, this.player.o2 + (reward.o2 ?? 0));
    this.player.energy = Math.min(100, this.player.energy + (reward.rcs ?? 0));
    this.player.repairHull(reward.hull ?? 0);

    this.audio.success();
    this.cameraRig.addShake(0.05);
    this.hud.toast(`Misión completada · ${mission.name}`, 'good', 4.5);
    this.renderPanelIfOpen();
  }

  /* --------------------------------------------------------------- consolas */

  openInteriorPoint(point) {
    this.seated = point.seat === true;
    this.openPanel(point.panel, point.id);
    this.audio.ui();
  }

  openPanel(kind, source = null) {
    if (!kind) return;
    this.panelOpen = kind;
    this.panelSource = source;
    if (kind === 'cockpit') this.seated = true;

    this.ignoreUnlock = true;
    if (document.pointerLockElement) document.exitPointerLock();
    this.controls.interactPressed = false;
    this.renderPanel();
    this.clock.getDelta();
    this.audio.ui();
  }

  closePanel() {
    if (!this.panelOpen) return;
    this.panelOpen = null;
    this.panelSource = null;
    this.seated = false;
    this.cameraRig.seated = false;
    this.hud.hidePanel();
    this.controls.interactPressed = false;
    this.ignoreUnlock = true;
    this.controls.requestLock();
    this.clock.getDelta();
    this.cameraRig.snap(this.player.group.position);
    this.audio.ui();
  }

  renderPanelIfOpen() {
    if (this.panelOpen) this.renderPanel();
  }

  _jobHtml() {
    if (!this.job) return '';
    const ratio = Math.max(0, Math.min(1, this.job.elapsed / this.job.duration));
    return `
      <div class="job">
        <span id="job-label">${this.job.label}</span>
        <div class="bar thin"><i id="job-fill" class="fill prompt-fill" style="transform:scaleX(${ratio.toFixed(3)})"></i></div>
      </div>
    `;
  }

  _missionRows() {
    return this.missions.list
      .map((mission) => {
        const progress = this.missions.progress(mission);
        const state =
          mission.state === 'active'
            ? 'ACTIVA'
            : mission.state === 'completed'
              ? 'COMPLETADA'
              : 'DISPONIBLE';
        const chips = mission.objectives
          .map(
            (item) =>
              `<span class="objective-chip ${item.progress >= item.target ? 'done' : ''}">${item.label} ${Math.min(item.progress, item.target)}/${item.target}</span>`
          )
          .join('');
        const reward = mission.reward;
        const disabled = mission.state === 'completed' || mission.state === 'active';
        return `
          <article class="mission-row ${mission.state === 'active' ? 'is-active' : ''} ${mission.state === 'completed' ? 'is-completed' : ''}">
            <div class="mission-row-head">
              <strong>${mission.name}</strong>
              <span>${MISSION_CATEGORIES[mission.category]} · ${mission.difficulty} · ${state}</span>
            </div>
            <p>${mission.description}</p>
            <div class="mission-objectives">${chips}</div>
            <div class="mission-row-head">
              <span>Recompensa: O2 +${reward.o2} · RCS +${reward.rcs} · Casco +${reward.hull}</span>
              <span>${progress.done}/${progress.total}</span>
            </div>
            <div class="mission-actions">
              <button class="btn small ${disabled ? 'ghost' : ''}" type="button" data-action="activate" data-id="${mission.id}" ${disabled ? 'disabled' : ''}>
                ${mission.state === 'active' ? 'En curso' : mission.state === 'completed' ? 'Completada' : 'Activar misión'}
              </button>
            </div>
          </article>
        `;
      })
      .join('');
  }

  _mapRows() {
    const playerPosition = this.player.group.position;
    return NAV_POIS.map((poi) => {
      const distance = poi.position.distanceTo(playerPosition);
      const selected = this.navTarget?.id === poi.id;
      const visited = this.visitedPois.has(poi.id);
      return `
        <div class="panel-row">
          <div class="grow">
            <strong>${poi.name}</strong>
            <span>${distance.toFixed(1)} m · ${selected ? 'destino marcado' : visited ? 'revisado' : 'pendiente'}</span>
          </div>
          <button class="btn small ${selected ? '' : 'ghost'}" type="button" data-action="nav" data-id="${poi.id}">
            ${selected ? 'Destino' : 'Marcar'}
          </button>
        </div>
      `;
    }).join('');
  }

  _statusRows() {
    const airlock = this.interior.getAirlockStatus();
    const leaks = this.station.active.length;
    return `
      <div class="panel-row"><div class="grow"><strong>Fugas activas</strong><span>${leaks} en el casco exterior</span></div><span class="${leaks ? 'off' : 'ok'}">${leaks ? 'ATENCIÓN' : 'OK'}</span></div>
      <div class="panel-row"><div class="grow"><strong>Integridad del traje</strong><span>Impactos y colisiones</span></div><span class="${this.player.hull < 40 ? 'off' : 'ok'}">${Math.round(this.player.hull)}%</span></div>
      <div class="panel-row"><div class="grow"><strong>Oxígeno</strong><span>${this.player.safe ? 'Recuperación en zona presurizada' : 'Consumo EVA'}</span></div><span class="${this.player.o2 < 25 ? 'off' : 'ok'}">${Math.round(this.player.o2)}%</span></div>
      <div class="panel-row"><div class="grow"><strong>RCS</strong><span>Combustible de propulsores</span></div><span class="${this.player.energy < 20 ? 'off' : 'ok'}">${Math.round(this.player.energy)}%</span></div>
      <div class="panel-row"><div class="grow"><strong>Esclusa</strong><span>Presión ${(airlock.pressure * 100).toFixed(0)}%</span></div><span class="${airlock.pressurized ? 'ok' : 'warn'}">${airlock.label}</span></div>
      <div class="panel-row"><div class="grow"><strong>Potencia del hábitat</strong><span>Circuitos restablecidos</span></div><span class="${this.interior.powerLevel > 0.9 ? 'ok' : 'warn'}">${Math.round(this.interior.powerLevel * 100)}%</span></div>
      <div class="panel-row"><div class="grow"><strong>Módulos</strong><span>${this.interior.stats.modules} habitables · ${this.interior.stats.doors} compuertas</span></div><span class="ok">OPERATIVO</span></div>
    `;
  }

  renderPanel() {
    if (!this.panelOpen) return;
    const kind = this.panelOpen;
    const airlock = this.interior.getAirlockStatus();

    if (kind === 'navigation' || kind === 'cockpit') {
      const seatNote =
        kind === 'cockpit'
          ? 'Puesto de mando · cámara fijada al asiento. Pulsa ESC para levantarte.'
          : 'Consola de navegación · selecciona una misión y marca un destino.';
      this.hud.showPanel({
        eyebrow: 'PUENTE DE MANDO · EVA-07',
        title: 'Navegación y misiones',
        subtitle: seatNote,
        html: `
          <div class="panel-section">
            <h3>Misiones disponibles</h3>
            <p>Una sola misión puede estar activa. El progreso se conserva al cruzar la esclusa o cambiar de habitación.</p>
            ${this._missionRows()}
          </div>
          <div class="panel-section">
            <h3>Mapa y destinos</h3>
            <div class="panel-grid">${this._mapRows()}</div>
          </div>
          <div class="panel-section">
            <h3>Estado de la estación</h3>
            <div class="panel-grid">${this._statusRows()}</div>
          </div>
          <div class="panel-section">
            <h3>Comunicaciones</h3>
            <div class="panel-row">
              <div class="grow"><strong>Enlace con Tierra</strong><span>${this.commsSent ? 'Informe transmitido · esperando acuse' : 'Canal listo para transmitir'}</span></div>
              <button class="btn small ${this.commsSent ? 'ghost' : ''}" type="button" data-action="comms">${this.commsSent ? 'Reenviar' : 'Transmitir informe'}</button>
            </div>
          </div>
          ${this._jobHtml()}
        `,
      });
      return;
    }

    if (kind === 'engineering') {
      const circuits = this.engineering.circuits
        .map(
          (done, index) => `
            <div class="panel-row">
              <div class="grow"><strong>Circuito ${index + 1}</strong><span>${done ? 'Restablecido' : 'Caído · sin tensión'}</span></div>
              ${done ? '<span class="ok">OK</span>' : `<button class="btn small" type="button" data-action="circuit" data-id="${index}">Restablecer</button>`}
            </div>
          `
        )
        .join('');
      this.hud.showPanel({
        eyebrow: 'SALA DE INGENIERÍA',
        title: 'Distribución de potencia',
        subtitle: 'Restablece los circuitos, diagnostica averías y repara el traje.',
        html: `
          <div class="panel-section">
            <h3>Circuitos</h3>
            ${circuits}
          </div>
          <div class="panel-section">
            <h3>Mantenimiento</h3>
            <div class="panel-grid">
              <div class="panel-row">
                <div class="grow"><strong>Reparar casco</strong><span>+${this.balance.values.hullRepair}% · ${this.repairCooldown > 0 ? `espera ${this.repairCooldown.toFixed(1)}s` : 'listo'}</span></div>
                <button class="btn small ${this.repairCooldown > 0 ? 'ghost' : ''}" type="button" data-action="repair-hull" ${this.repairCooldown > 0 ? 'disabled' : ''}>Reparar</button>
              </div>
              <div class="panel-row">
                <div class="grow"><strong>Diagnóstico</strong><span>Lectura de sistemas y recursos</span></div>
                <button class="btn small ghost" type="button" data-action="diagnose">Escanear</button>
              </div>
            </div>
          </div>
          ${this._jobHtml()}
        `,
      });
      return;
    }

    if (kind === 'lab') {
      const samples = this.lab.samples
        .map(
          (done, index) => `
            <div class="panel-row">
              <div class="grow"><strong>Muestra ${index + 1}</strong><span>${done ? 'Analizada · resultados registrados' : 'Pendiente de análisis'}</span></div>
              ${done ? '<span class="ok">OK</span>' : `<button class="btn small" type="button" data-action="sample" data-id="${index}">Analizar</button>`}
            </div>
          `
        )
        .join('');
      this.hud.showPanel({
        eyebrow: 'LABORATORIO CIENTÍFICO',
        title: 'Análisis y experimentos',
        subtitle: 'Analiza muestras, calibra instrumentos y registra resultados.',
        html: `
          <div class="panel-section">
            <h3>Muestras</h3>
            ${samples}
          </div>
          <div class="panel-section">
            <h3>Instrumentación</h3>
            <div class="panel-grid">
              <div class="panel-row">
                <div class="grow"><strong>Calibrar espectrómetro</strong><span>${this.lab.calibrated ? 'Calibrado' : 'Deriva detectada'}</span></div>
                <button class="btn small ${this.lab.calibrated ? 'ghost' : ''}" type="button" data-action="calibrate">${this.lab.calibrated ? 'Revisar' : 'Calibrar'}</button>
              </div>
              <div class="panel-row">
                <div class="grow"><strong>Resultados registrados</strong><span>Informe científico</span></div>
                <span class="ok">${this.scienceData}</span>
              </div>
            </div>
          </div>
          ${this._jobHtml()}
        `,
      });
      return;
    }

    if (kind === 'storage') {
      this.hud.showPanel({
        eyebrow: 'ALMACÉN Y EQUIPAMIENTO',
        title: 'Preparación EVA',
        subtitle: 'Recoge componentes, filtros y muestras; recarga recursos antes de salir.',
        html: `
          <div class="panel-section">
            <h3>Inventario</h3>
            <div class="panel-grid">
              <div class="panel-row"><div class="grow"><strong>Kits de repuesto</strong><span>Regulador de potencia</span></div><span class="${this.inventory.component ? 'ok' : 'warn'}">${this.inventory.component}</span></div>
              <div class="panel-row"><div class="grow"><strong>Filtros de O2</strong><span>Soporte vital</span></div><span class="${this.inventory.filter ? 'ok' : 'warn'}">${this.inventory.filter}</span></div>
              <div class="panel-row"><div class="grow"><strong>Muestras</strong><span>Laboratorio</span></div><span class="${this.inventory.sample ? 'ok' : 'warn'}">${this.inventory.sample}</span></div>
              <div class="panel-row"><div class="grow"><strong>Herramientas recuperadas</strong><span>EVA</span></div><span class="ok">${this.inventory.tools}</span></div>
            </div>
          </div>
          <div class="panel-section">
            <h3>Recoger material</h3>
            <div class="panel-grid">
              <button class="btn small ghost" type="button" data-action="take-component">Kit de repuesto +1</button>
              <button class="btn small ghost" type="button" data-action="take-filter">Filtro de O2 +1</button>
              <button class="btn small ghost" type="button" data-action="take-sample">Muestra +1</button>
            </div>
          </div>
          <div class="panel-section">
            <h3>Recarga y reparación</h3>
            <div class="panel-grid">
              <div class="panel-row"><div class="grow"><strong>Oxígeno</strong><span>${Math.round(this.player.o2)}%</span></div><button class="btn small ghost" type="button" data-action="refill-o2">Recargar</button></div>
              <div class="panel-row"><div class="grow"><strong>RCS</strong><span>${Math.round(this.player.energy)}%</span></div><button class="btn small ghost" type="button" data-action="refill-rcs">Recargar</button></div>
              <div class="panel-row"><div class="grow"><strong>Casco</strong><span>${Math.round(this.player.hull)}% · ${this.repairCooldown > 0 ? 'en espera' : 'listo'}</span></div><button class="btn small ghost" type="button" data-action="repair-hull" ${this.repairCooldown > 0 ? 'disabled' : ''}>Reparar</button></div>
            </div>
          </div>
        `,
      });
      return;
    }

    if (kind === 'life') {
      const filters = this.lifeSupport.filters
        .map(
          (done, index) => `
            <div class="panel-row">
              <div class="grow"><strong>Filtro ${index + 1}</strong><span>${done ? 'Sustituido' : 'Saturado'}</span></div>
              ${done ? '<span class="ok">OK</span>' : `<button class="btn small" type="button" data-action="filter" data-id="${index}">Sustituir</button>`}
            </div>
          `
        )
        .join('');
      this.hud.showPanel({
        eyebrow: 'SOPORTE VITAL · PASILLO',
        title: 'Control ambiental',
        subtitle: 'Sustituye los filtros de O2 y revisa la presión de los módulos.',
        html: `
          <div class="panel-section">
            <h3>Filtros de oxígeno</h3>
            ${filters}
          </div>
          <div class="panel-section">
            <h3>Estado</h3>
            <div class="panel-grid">
              <div class="panel-row"><div class="grow"><strong>Filtros en inventario</strong><span>Recoge más en el almacén</span></div><span class="${this.inventory.filter ? 'ok' : 'warn'}">${this.inventory.filter}</span></div>
              <div class="panel-row"><div class="grow"><strong>Recuperación de O2</strong><span>Eficiencia del sistema</span></div><span class="ok">${this.player.o2RegenScale.toFixed(1)}×</span></div>
              <div class="panel-row"><div class="grow"><strong>Presión de esclusa</strong><span>${airlock.label}</span></div><span class="${airlock.pressurized ? 'ok' : 'warn'}">${(airlock.pressure * 100).toFixed(0)}%</span></div>
            </div>
          </div>
          ${this._jobHtml()}
        `,
      });
    }
  }

  handlePanelAction(action, id) {
    if (!action) return;

    if (action === 'activate') {
      const result = this.missions.activate(id);
      if (!result.ok) {
        this.hud.toast(result.reason, 'warn', 2.4);
        return;
      }
      // Si el jugador ya llevaba el kit, el objetivo de recogida cuenta.
      if (id === 'component_swap' && this.inventory.component > 0) {
        this.missions.setProgress('component_pickup', 1);
      }
      this.audio.ui();
      this.hud.toast(`Misión activa · ${result.mission.name}`, 'good', 3);
      this.renderPanel();
      return;
    }

    if (action === 'nav') {
      const poi = NAV_POIS.find((item) => item.id === id);
      if (!poi) return;
      this.navTarget = poi;
      if (this.missions.activeId === 'navigation_survey' && !this.visitedPois.has(id)) {
        this.visitedPois.add(id);
        this.missions.notify('poi', 1);
      }
      this.hud.toast(`Destino marcado · ${poi.name}`, 'good', 2.4);
      this.audio.ui();
      this.renderPanel();
      return;
    }

    if (action === 'comms') {
      this.commsSent = true;
      this.hud.toast('Informe transmitido a Tierra · enlace estable', 'good', 3);
      this.audio.ping();
      this.renderPanel();
      return;
    }

    if (action === 'circuit') {
      const index = Number(id);
      if (this.engineering.circuits[index]) return;
      this.startJob({
        id: `circuit-${index}`,
        label: `Restableciendo circuito ${index + 1}`,
        duration: 2.6,
        source: 'engineering',
        onComplete: () => {
          this.engineering.circuits[index] = true;
          const count = this.engineering.circuits.filter(Boolean).length;
          this.interior.setPower(0.72 + (count / 3) * 0.28);
          this.missions.notify('circuit', 1);
          this.hud.toast(`Circuito ${index + 1} restablecido`, 'good', 2.6);
        },
      });
      return;
    }

    if (action === 'sample') {
      const index = Number(id);
      if (this.lab.samples[index]) return;
      this.startJob({
        id: `sample-${index}`,
        label: `Analizando muestra ${index + 1}`,
        duration: 2.2,
        source: 'lab',
        onComplete: () => {
          this.lab.samples[index] = true;
          this.scienceData += 1;
          this.missions.notify('sample', 1);
          this.hud.toast(`Muestra ${index + 1} analizada`, 'good', 2.6);
        },
      });
      return;
    }

    if (action === 'calibrate') {
      this.startJob({
        id: 'calibrate',
        label: 'Calibrando espectrómetro',
        duration: 2.0,
        source: 'lab',
        onComplete: () => {
          this.lab.calibrated = true;
          this.hud.toast('Espectrómetro calibrado', 'good', 2.6);
        },
      });
      return;
    }

    if (action === 'filter') {
      const index = Number(id);
      if (this.lifeSupport.filters[index]) return;
      if (this.inventory.filter <= 0) {
        this.hud.toast('No quedan filtros · recógelos en el almacén', 'warn', 3);
        return;
      }
      this.startJob({
        id: `filter-${index}`,
        label: `Sustituyendo filtro ${index + 1}`,
        duration: 2.4,
        source: 'life_support',
        onComplete: () => {
          this.inventory.filter -= 1;
          this.lifeSupport.filters[index] = true;
          const count = this.lifeSupport.filters.filter(Boolean).length;
          this.player.o2RegenScale = 1 + count * 0.25;
          this.missions.notify('filter', 1);
          this.hud.toast(`Filtro ${index + 1} sustituido`, 'good', 2.6);
        },
      });
      return;
    }

    if (action === 'repair-hull') {
      if (this.repairCooldown > 0) return;
      this.player.repairHull(this.balance.values.hullRepair);
      this.repairCooldown = this.balance.values.hullRepairCooldown;
      this.hud.toast(`Casco reparado · ${Math.round(this.player.hull)}%`, 'good', 2.4);
      this.audio.success();
      this.renderPanel();
      return;
    }

    if (action === 'diagnose') {
      this.hud.toast(
        `Diagnóstico · O2 ${Math.round(this.player.o2)}% · RCS ${Math.round(this.player.energy)}% · Casco ${Math.round(this.player.hull)}%`,
        'good',
        4
      );
      this.audio.ping();
      return;
    }

    if (action === 'take-component') {
      this.inventory.component += 1;
      if (this.missions.activeId === 'component_swap') this.missions.notify('component_pickup', 1);
      this.hud.toast('Kit de repuesto recogido', 'good', 2.2);
      this.renderPanel();
      return;
    }

    if (action === 'take-filter') {
      this.inventory.filter += 1;
      this.hud.toast('Filtro de O2 recogido', 'good', 2.2);
      this.renderPanel();
      return;
    }

    if (action === 'take-sample') {
      this.inventory.sample += 1;
      this.hud.toast('Muestra recogida', 'good', 2.2);
      this.renderPanel();
      return;
    }

    if (action === 'refill-o2') {
      this.player.o2 = 100;
      this.hud.toast('Oxígeno al 100%', 'good', 2.2);
      this.renderPanel();
      return;
    }

    if (action === 'refill-rcs') {
      this.player.energy = 100;
      this.hud.toast('RCS al 100%', 'good', 2.2);
      this.renderPanel();
    }
  }

  startJob({ id, label, duration, source, onComplete }) {
    if (this.job) {
      this.hud.toast('Ya hay una tarea en curso', 'warn', 2);
      return;
    }
    this.job = { id, label, duration, source, onComplete, elapsed: 0 };
    this.hud.toast(label, 'good', 2.4);
    this.renderPanel();
  }

  updateJobs(dt) {
    if (!this.job) return;

    const point = this.interiorSystems.points.find((item) => item.id === this.job.source);
    if (point && point.group.position.distanceTo(this.player.group.position) > 3.8) {
      this.hud.toast('Tarea cancelada · vuelve a la consola', 'warn', 2.6);
      this.job = null;
      this.renderPanelIfOpen();
      return;
    }

    this.job.elapsed += dt;
    const ratio = Math.min(1, this.job.elapsed / this.job.duration);
    this.hud.setJobProgress(ratio, this.job.label);

    if (ratio >= 1) {
      const job = this.job;
      this.job = null;
      job.onComplete?.();
      this.audio.success();
      this.renderPanelIfOpen();
    }
  }

  /* -------------------------------------------------------------- audio/HUD */

  updateAudio() {
    this.audio.setThruster(
      this.player.thrusting ? (this.controls.boost ? 1 : 0.6) : 0
    );
    this.audio.setWelder(this.repairing);

    const ratio = this.player.o2 / 100;
    this.audio.setBreathing(0.9 + (1 - ratio) * 1.3);
  }

  updateHUD() {
    this.integrity = this.player.hull;
    this.hud.setStats(this.player.o2, this.player.energy, this.player.hull);
    this.hud.setClock(this.time);
    this.hud.setMission(this.missions.active);
    this.hud.setTether(this.tether.status);
    this.hud.setPressure(this.interior.getAirlockStatus());

    if (this.navTarget) {
      this.hud.setNavigation({
        name: this.navTarget.name,
        distance: this.navTarget.position.distanceTo(this.player.group.position),
      });
    } else {
      this.hud.setNavigation(null);
    }

    const warnings = [];
    if (this.player.o2 < 25) warnings.push('OXÍGENO BAJO');
    if (this.player.hull < 35) warnings.push('CASCO DAÑADO · REPARA EN INGENIERÍA');
    if (this.player.energy < 15) warnings.push('RCS BAJO');
    if (this.tether.tension > 0.8) warnings.push('CABLE AL LÍMITE');
    if (!this.interior.getAirlockStatus().pressurized && this.interior._inAirlock(this.player.group.position)) {
      warnings.push('ESCLUSA DESPRESURIZADA');
    }
    this.hud.setWarnings(warnings);

    this.hud.updateMarkers(
      this.station.active,
      this.camera,
      this.player.group.position,
      this.time < this.revealUntil
    );
  }

  selectTool(index) {
    if (index < 0 || index >= TOOLS.length) return;
    this.toolIndex = index;
    this.toolRig.set(index);
    this.hud.setTool(index);
    this.audio.ui();
  }

  /* ---------------------------------------------------------------- estados */

  start() {
    this.audio.init();
    this.reset();

    this.state = 'playing';
    this.hud.screen(null);
    this.hud.show();
    this.controls.requestLock();
    this.clock.getDelta();
  }

  reset() {
    this.time = 0;
    this.integrity = 100;
    this.toolIndex = 0;
    this.repairing = false;
    this.revealUntil = 0;
    this.scanCooldown = 0;
    this.alarmTimer = 0;
    this.sparkAccum = 0;
    this.hadLock = false;
    this.panelOpen = null;
    this.panelSource = null;
    this.job = null;
    this.seated = false;
    this.navTarget = null;
    this.visitedPois.clear();
    this.commsSent = false;
    this.repairCooldown = 0;
    this.lastDamageToast = 0;
    this.scienceData = 0;

    this.inventory = { component: 0, filter: 0, sample: 0, tools: 0 };
    this.engineering = { circuits: [false, false, false] };
    this.lifeSupport = { filters: [false, false] };
    this.lab = { samples: [false, false, false], calibrated: false };

    this.missions.reset();
    this.player.reset();
    this.station.reset();
    this.interior.reset();
    this.interior.setPower(0.72);
    this.exteriorTasks.reset();
    this.tether.reset();

    this.environment.setInterior(false);
    this.cameraRig.inside = false;
    this.cameraRig.seated = false;
    this.toolRig.set(0);
    this.hud.setTool(0);
    this.hud.setStats(100, 100, 100);
    this.hud.setMission(this.missions.active);
    this.hud.setTether({ active: false, distance: 0, max: this.tether.max, tension: 0 });
    this.hud.setPressure(this.interior.getAirlockStatus());
    this.hud.setNavigation(null);
    this.hud.setWarnings([]);
    this.hud.setClock(0);
    this.hud.setCrosshair('none');
    this.hud.hidePrompt();
    this.hud.hidePanel();
    this.hud.screen(null);

    this.cameraRig.yaw = 0;
    this.cameraRig.pitch = 0.16;
    this.cameraRig.distance = 6.2;
    this.cameraRig.targetDistance = 6.2;
    this.cameraRig.snap(this.player.group.position);

    this.audio.silenceLoops();
    this.audio.setBreathing(1);
  }

  pause() {
    if (this.state !== 'playing') return;
    if (this.panelOpen) {
      this.closePanel();
      return;
    }
    this.state = 'paused';
    this.needsRender = true;
    this.audio.silenceLoops();
    this.hud.screen('pause');
    if (document.pointerLockElement) document.exitPointerLock();
  }

  resume() {
    if (this.state !== 'paused') return;
    this.state = 'playing';
    this.hud.screen(null);
    this.ignoreUnlock = true;
    this.controls.requestLock();
    this.clock.getDelta();
  }

  win() {
    if (this.state !== 'playing') return;
    this.state = 'won';
    this.needsRender = true;
    this.audio.silenceLoops();
    this.audio.victory();
    this.hud.hidePanel();

    this.hud.setWinStats({
      repairs: this.station.repairedCount,
      time: this.time,
      integrity: this.player.hull,
      o2: this.player.o2,
    });
    this.hud.screen('win');
    this.hud.hide();
    if (document.pointerLockElement) document.exitPointerLock();
  }

  lose(title, reason) {
    if (this.state !== 'playing') return;
    this.state = 'lost';
    this.needsRender = true;
    this.audio.silenceLoops();
    this.audio.fail();
    this.hud.hidePanel();

    this.hud.setLoseStats({
      title,
      reason,
      repairs: this.station.repairedCount,
      time: this.time,
    });
    this.hud.screen('lose');
    this.hud.hide();
    if (document.pointerLockElement) document.exitPointerLock();
  }
}
