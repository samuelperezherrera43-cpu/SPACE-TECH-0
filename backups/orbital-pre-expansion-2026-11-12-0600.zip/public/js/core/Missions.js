/**
 * Sistema modular de misiones.
 *
 * Cada misión declara sus objetivos y el tipo de evento que los progresa.
 * El MissionManager sólo mantiene una misión activa a la vez: los eventos
 * del mundo llaman a notify(type) y únicamente la misión activa avanza.
 * Añadir una misión nueva es añadir un objeto a MISSIONS.
 */

export const MISSION_CATEGORIES = {
  exterior: 'Exterior EVA',
  interior: 'Interior',
  navigation: 'Navegación',
  science: 'Ciencia',
  maintenance: 'Mantenimiento',
};

export const MISSION_DIFFICULTY = ['Fácil', 'Normal', 'Difícil'];

const objective = (id, label, type, target) => ({
  id,
  label,
  type,
  target,
  progress: 0,
});

export const MISSIONS = [
  {
    id: 'leak_repair',
    name: 'Reparación de fugas',
    category: 'maintenance',
    scope: 'exterior',
    difficulty: 'Normal',
    description:
      'La estación pierde presión por microfisuras y válvulas dañadas. Localiza las fugas con el escáner y séllalas con el soldador o la llave.',
    reward: { o2: 25, rcs: 20, hull: 10 },
    objectives: [objective('leaks', 'Sellar fugas del casco', 'leaks', 4)],
  },
  {
    id: 'solar_repair',
    name: 'Reparación de paneles solares',
    category: 'exterior',
    scope: 'exterior',
    difficulty: 'Normal',
    description:
      'Tres celdas de los paneles han perdido conexión. Recorre los puntos marcados y suelda los conectores con el soldador.',
    reward: { o2: 20, rcs: 18, hull: 8 },
    objectives: [objective('solar', 'Reparar celdas solares', 'solar', 3)],
  },
  {
    id: 'antenna_repair',
    name: 'Reparación de antena',
    category: 'exterior',
    scope: 'exterior',
    difficulty: 'Fácil',
    description:
      'La antena de banda X no responde. Ajusta los dos actuadores del mástil con la llave y recupera el enlace con Tierra.',
    reward: { o2: 15, rcs: 15, hull: 6 },
    objectives: [objective('antenna', 'Ajustar actuadores', 'antenna', 2)],
  },
  {
    id: 'component_swap',
    name: 'Sustitución de componentes',
    category: 'maintenance',
    scope: 'mixed',
    difficulty: 'Normal',
    description:
      'El regulador de potencia exterior está agotado. Recoge un kit de repuesto en el almacén y sustitúyelo en la toma del módulo.',
    reward: { o2: 18, rcs: 22, hull: 12 },
    objectives: [
      objective('pickup', 'Recoger kit en el almacén', 'component_pickup', 1),
      objective('install', 'Instalar el regulador', 'component_install', 1),
    ],
  },
  {
    id: 'module_inspection',
    name: 'Inspección de módulos',
    category: 'maintenance',
    scope: 'exterior',
    difficulty: 'Fácil',
    description:
      'Inspecciona tres puntos críticos del casco con el escáner para registrar el estado estructural de la estación.',
    reward: { o2: 14, rcs: 12, hull: 5 },
    objectives: [objective('inspection', 'Inspeccionar módulos', 'inspection', 3)],
  },
  {
    id: 'tool_recovery',
    name: 'Recuperación de herramientas',
    category: 'exterior',
    scope: 'exterior',
    difficulty: 'Fácil',
    description:
      'Dos herramientas se soltaron durante la última EVA y flotan cerca de la estación. Recupéralas antes de que se pierdan.',
    reward: { o2: 12, rcs: 25, hull: 4 },
    objectives: [objective('tools', 'Recuperar herramientas', 'tool_pickup', 2)],
  },
  {
    id: 'engineering_power',
    name: 'Restablecer circuitos',
    category: 'interior',
    scope: 'interior',
    difficulty: 'Normal',
    description:
      'La sala de ingeniería tiene tres circuitos caídos. Restablécelos desde la consola para devolver la potencia plena al hábitat.',
    reward: { o2: 20, rcs: 20, hull: 10 },
    objectives: [objective('circuits', 'Restablecer circuitos', 'circuit', 3)],
  },
  {
    id: 'life_support',
    name: 'Sustituir filtros de O2',
    category: 'interior',
    scope: 'interior',
    difficulty: 'Fácil',
    description:
      'Los filtros del sistema de soporte vital están saturados. Recoge dos filtros en el almacén y cámbialos en el panel del pasillo.',
    reward: { o2: 30, rcs: 10, hull: 8 },
    objectives: [objective('filters', 'Sustituir filtros', 'filter', 2)],
  },
  {
    id: 'lab_analysis',
    name: 'Analizar muestras',
    category: 'science',
    scope: 'interior',
    difficulty: 'Fácil',
    description:
      'El laboratorio guarda tres muestras pendientes. Analízalas y registra los resultados para completar el informe científico.',
    reward: { o2: 16, rcs: 12, hull: 8 },
    objectives: [objective('samples', 'Analizar muestras', 'sample', 3)],
  },
  {
    id: 'navigation_survey',
    name: 'Reconocimiento de navegación',
    category: 'navigation',
    scope: 'interior',
    difficulty: 'Fácil',
    description:
      'Revisa tres puntos de interés desde el mapa del puente de mando y marca un destino para la próxima ventana orbital.',
    reward: { o2: 14, rcs: 18, hull: 6 },
    objectives: [objective('pois', 'Revisar puntos de interés', 'poi', 3)],
  },
];

export class MissionManager {
  constructor() {
    this.onComplete = null;
    this.onActivate = null;
    this.reset();
  }

  reset() {
    this.missions = MISSIONS.map((definition) => ({
      ...definition,
      objectives: definition.objectives.map((item) => ({ ...item, progress: 0 })),
      state: 'available',
    }));
    this.activeId = 'leak_repair';
    const active = this.getById(this.activeId);
    if (active) active.state = 'active';
  }

  get list() {
    return this.missions;
  }

  getById(id) {
    return this.missions.find((mission) => mission.id === id) ?? null;
  }

  get active() {
    return this.getById(this.activeId);
  }

  get completedCount() {
    return this.missions.filter((mission) => mission.state === 'completed').length;
  }

  activate(id) {
    const mission = this.getById(id);
    if (!mission || mission.state === 'completed') {
      return { ok: false, reason: 'Misión completada o inexistente.' };
    }
    if (this.activeId === id) return { ok: true, mission };

    const previous = this.active;
    if (previous && previous.state === 'active') previous.state = 'available';

    this.activeId = id;
    mission.state = 'active';
    this.onActivate?.(mission);
    return { ok: true, mission };
  }

  /** Progreso de un objetivo. Devuelve la misión si se completó. */
  notify(type, amount = 1) {
    const mission = this.active;
    if (!mission) return null;

    const targets = mission.objectives.filter((item) => item.type === type);
    if (targets.length === 0) return null;

    for (const item of targets) {
      item.progress = Math.min(item.target, item.progress + amount);
    }

    if (this.isComplete(mission)) {
      mission.state = 'completed';
      this.activeId = null;
      this.onComplete?.(mission);
      return mission;
    }
    return null;
  }

  isComplete(mission = this.active) {
    if (!mission) return false;
    return mission.objectives.every((item) => item.progress >= item.target);
  }

  progress(mission = this.active) {
    if (!mission) return { done: 0, total: 0, ratio: 0 };
    const total = mission.objectives.reduce((sum, item) => sum + item.target, 0);
    const done = mission.objectives.reduce(
      (sum, item) => sum + Math.min(item.target, item.progress),
      0
    );
    return { done, total, ratio: total > 0 ? done / total : 0 };
  }

  setProgress(type, value) {
    const mission = this.active;
    if (!mission) return;
    for (const item of mission.objectives) {
      if (item.type === type) item.progress = Math.min(item.target, value);
    }
  }
}
