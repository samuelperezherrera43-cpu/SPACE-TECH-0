/**
 * Smoke test con Chrome real (headless) usando puppeteer-core.
 * Requiere Chrome instalado. Uso: npm run smoke
 */
import { spawn } from 'node:child_process';
import puppeteer from 'puppeteer-core';
import { existsSync, mkdirSync } from 'node:fs';

const SHOTS = '.smoke';
mkdirSync(SHOTS, { recursive: true });

const CHROME_CANDIDATES = [
  process.env.CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
].filter(Boolean);

const executablePath = CHROME_CANDIDATES.find((path) => existsSync(path));
if (!executablePath) {
  console.error('No se encontró Chrome. Define CHROME_PATH.');
  process.exit(1);
}

const PORT = 5199;
const server = spawn(process.execPath, ['scripts/dev.mjs'], {
  env: { ...process.env, PORT: String(PORT), LIVE_RELOAD: '0' },
  stdio: 'ignore',
});

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

let browser;
let failures = 0;

function check(name, condition, detail = '') {
  if (condition) {
    console.log(`  ok   ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name} ${detail}`);
  }
}

try {
  await sleep(900);

  browser = await puppeteer.launch({
    executablePath,
    headless: 'new',
    args: [
      '--no-sandbox',
      '--enable-unsafe-swiftshader',
      '--use-angle=swiftshader',
      '--disable-background-timer-throttling',
      '--disable-renderer-backgrounding',
      '--disable-backgrounding-occluded-windows',
      '--window-size=1280,800',
    ],
  });

  const page = await browser.newPage();
  await page.setViewport({ width: 1280, height: 800 });

  const errors = [];
  page.on('console', (message) => {
    if (message.type() === 'error') errors.push(message.text());
  });
  page.on('pageerror', (error) => errors.push(`pageerror: ${error.message}`));

  await page.goto(`http://localhost:${PORT}/`, { waitUntil: 'networkidle0', timeout: 30000 });
  await page.waitForFunction(() => !!window.__orbital, { timeout: 15000 });

  // El render por software es lento: usar el preset ligero para que el smoke
  // no dependa del framerate real.
  await page.evaluate(() => window.__orbital.quality.set('performance'));
  await sleep(300);

  await page.screenshot({ path: `${SHOTS}/start.png` });
  console.log('\nPantalla de inicio capturada.');

  await page.click('#btn-start');
  await sleep(1400);

  const initial = await page.evaluate(() => {
    const game = window.__orbital;
    return {
      state: game.state,
      o2: game.player.o2,
      energy: game.player.energy,
      active: game.station.active.length,
      position: game.player.group.position.toArray(),
      camera: game.camera.position.toArray(),
      calls: game.renderer.info.render.calls,
      triangles: game.renderer.info.render.triangles,
      hudVisible: !document.querySelector('#hud').classList.contains('hidden'),
    };
  });

  check('estado "playing"', initial.state === 'playing', initial.state);
  check('3 fugas activas', initial.active === 3, String(initial.active));
  check('HUD visible', initial.hudVisible);
  check('jugador en escena', initial.position.some((v) => Math.abs(v) > 1), JSON.stringify(initial.position));
  check('render activo', initial.calls > 0, `${initial.calls} draw calls`);

  console.log(`  info draw calls: ${initial.calls} · triángulos: ${initial.triangles}`);

  /* --------------------------------------------------- interior habitable */

  await page.evaluate(async () => {
    await window.__orbital.interior.ready;
  });

  const interior = await page.evaluate(() => {
    const game = window.__orbital;
    return {
      loaded: game.interior.loaded,
      modules: game.interior.stats.modules,
      colliders: game.interior.stats.colliders,
      doors: game.interior.stats.doors,
    };
  });

  check('interior GLB cargado', interior.loaded);
  check('6 módulos transitables', interior.modules === 6, String(interior.modules));
  check('colisionadores creados', interior.colliders > 40, String(interior.colliders));
  check('6 compuertas', interior.doors === 6, String(interior.doors));

  // La tecla E real llega al sistema de entrada (mismo flag que consume Game).
  const keyWiring = await page.evaluate(() => {
    const game = window.__orbital;
    game.controls.interactPressed = false;
    window.dispatchEvent(new KeyboardEvent('keydown', { code: 'KeyE' }));
    const pressed = game.controls.interactPressed;
    window.dispatchEvent(new KeyboardEvent('keyup', { code: 'KeyE' }));
    game.controls.interactPressed = false;
    return pressed;
  });
  check('la tecla E llega a Controls', keyWiring === true);

  // Cambio de dificultad en caliente y vuelta a Exploración.
  const difficulty = await page.evaluate(() => {
    const game = window.__orbital;
    const before = game.balance.id;
    game.balance.set('challenge');
    const drain = game.balance.values.o2Drain;
    const tether = game.tether.max;
    game.balance.set('exploration');
    return { before, drain, tether, after: game.balance.id, restored: game.tether.max };
  });
  check(
    'la dificultad cambia consumos y cable',
    difficulty.before === 'exploration' &&
      difficulty.drain > 0.8 &&
      difficulty.tether === 24 &&
      difficulty.after === 'exploration' &&
      difficulty.restored === 32,
    JSON.stringify(difficulty)
  );

  // Entrada: la compuerta exterior sólo se abre con E.
  const approach = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, 6.9);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);

    const action = game.interior.getAirlockAction(game.player.group.position);
    game.controls.interactPressed = true;
    game.update(1 / 60);
    for (let i = 0; i < 60; i++) game.update(1 / 60);

    const outer = game.interior.doors.find((door) => door.id === 'airlock_outer');
    return {
      action,
      outer: outer.progress,
      phase: game.interior.airlock.phase,
      prompt: document.querySelector('#prompt-label').textContent,
    };
  });
  check(
    'esclusa: E abre la compuerta exterior',
    approach.action?.type === 'enter' && approach.outer > 0.8,
    JSON.stringify(approach)
  );

  // Dentro de la esclusa: cierra exterior, presuriza y abre interior.
  const cycle = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, 4.1);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    for (let i = 0; i < 150; i++) game.update(1 / 60);

    const outer = game.interior.doors.find((door) => door.id === 'airlock_outer');
    const inner = game.interior.doors.find((door) => door.id === 'airlock_inner');
    return {
      outer: outer.progress,
      inner: inner.progress,
      phase: game.interior.airlock.phase,
      pressure: game.interior.airlock.pressure,
    };
  });
  check('esclusa: exterior cierra', cycle.outer < 0.2, String(cycle.outer));
  check(
    'esclusa: presuriza y abre interior',
    cycle.inner > 0.8 && cycle.pressure > 0.9,
    JSON.stringify(cycle)
  );

  // Al pasillo: se cierra la interior y el jugador queda dentro.
  const inside = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, 0);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    for (let i = 0; i < 90; i++) game.update(1 / 60);

    const inner = game.interior.doors.find((door) => door.id === 'airlock_inner');
    return {
      inner: inner.progress,
      phase: game.interior.airlock.phase,
      inside: game.player.inside,
      safe: game.player.safe,
      state: game.state,
      position: game.player.group.position.toArray(),
    };
  });
  check('esclusa: interior cierra tras entrar', inside.inner < 0.2, String(inside.inner));
  check('jugador dentro, a salvo y misión intacta', inside.inside && inside.safe && inside.state === 'playing');
  check('posición conservada (sin teleport)', Math.abs(inside.position[2]) < 0.4, JSON.stringify(inside.position));

  // Salida: E en la compuerta interior, despresurizar y abrir exterior.
  const exitStart = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, 1.9);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    const action = game.interior.getAirlockAction(game.player.group.position);
    game.controls.interactPressed = true;
    game.update(1 / 60);
    for (let i = 0; i < 45; i++) game.update(1 / 60);
    return { action, phase: game.interior.airlock.phase };
  });
  check(
    'esclusa: E abre la compuerta interior',
    exitStart.action?.type === 'exit' && exitStart.phase === 'innerOpen',
    JSON.stringify(exitStart)
  );

  const exitCycle = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, 3.4);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    for (let i = 0; i < 180; i++) game.update(1 / 60);
    const outer = game.interior.doors.find((door) => door.id === 'airlock_outer');
    return {
      outer: outer.progress,
      phase: game.interior.airlock.phase,
      pressure: game.interior.airlock.pressure,
    };
  });
  check(
    'esclusa: despresuriza y abre al exterior',
    exitCycle.outer > 0.8 && exitCycle.pressure < 0.1,
    JSON.stringify(exitCycle)
  );

  const exited = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, 6.9);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    for (let i = 0; i < 120; i++) game.update(1 / 60);
    return {
      phase: game.interior.airlock.phase,
      pressure: game.interior.airlock.pressure,
      tether: game.tether.status,
      safe: game.player.safe,
    };
  });
  check('esclusa: queda en vacío tras salir', exited.phase === 'vacuum' && exited.pressure < 0.1, JSON.stringify(exited));
  check('cable EVA conectado automáticamente', exited.tether.active && exited.tether.distance > 0, JSON.stringify(exited.tether));
  await page.screenshot({ path: `${SHOTS}/eva.png` });

  // Puerta automática del centro de operaciones.
  const autoDoor = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0.7, -8.8, -1.5);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    for (let i = 0; i < 45; i++) game.update(1 / 60);
    const door = game.interior.doors.find((item) => item.id === 'ops');
    return door.progress;
  });
  check('puerta de operaciones automática', autoDoor > 0.6, String(autoDoor));

  // Colisión: empuje lateral contra la pared este del pasillo.
  const wall = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, 0);
    game.player.body.velocity.set(8, 0, 0);
    for (let i = 0; i < 60; i++) game.update(1 / 60);
    return game.player.group.position.toArray();
  });
  check('pared del pasillo bloquea al jugador', wall[0] < 1.25, JSON.stringify(wall));

  // Captura del interior (cabina, ventanas y consola).
  await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, -11.2);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.cameraRig.yaw = 0;
    game.cameraRig.pitch = 0.12;
    game.cameraRig.distance = 4.6;
    game.cameraRig.targetDistance = 4.6;
    game.cameraRig.snap(game.player.group.position);
    for (let i = 0; i < 30; i++) game.update(1 / 60);
  });
  await page.screenshot({ path: `${SHOTS}/interior.png` });
  console.log('  Captura del interior guardada.');

  // Captura del pasillo (puertas automáticas, tiras de luz y escala).
  await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, -3.2);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.cameraRig.yaw = 0;
    game.cameraRig.pitch = 0.1;
    game.cameraRig.distance = 4.2;
    game.cameraRig.targetDistance = 4.2;
    game.cameraRig.snap(game.player.group.position);
    for (let i = 0; i < 30; i++) game.update(1 / 60);
  });
  await page.screenshot({ path: `${SHOTS}/interior-corridor.png` });
  console.log('  Captura del pasillo guardada.');

  /* ------------------------------------------------------ reparación EVA */

  // Colocar al jugador junto a la primera fuga, apuntar la cámara y reparar.
  const target = await page.evaluate(() => {
    const game = window.__orbital;
    const breach = game.station.active[0];
    const normal = breach.normal;

    const position = breach.position.clone().addScaledVector(normal, 2.5);
    game.player.body.position.set(position.x, position.y, position.z);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);

    game.selectTool(breach.type === 'hull' ? 0 : 1);

    // Congelar la cámara y mirar directamente a la fuga desde un ángulo
    // lateral: el rayo central debe entrar en su esfera de impacto.
    game.cameraRig.update = () => {};

    const tangent = breach.normal.clone().set(1, 0, 0);
    if (Math.abs(tangent.dot(normal)) > 0.9) tangent.set(0, 0, 1);
    tangent.cross(normal).normalize();

    const camPos = breach.position.clone()
      .addScaledVector(normal, 1.6)
      .addScaledVector(tangent, 2.2);

    game.camera.position.copy(camPos);
    game.camera.lookAt(breach.position);
    game.camera.updateMatrixWorld(true);

    game.controls.mouse.left = true;

    return {
      id: breach.id,
      type: breach.type,
      progress: breach.progress,
      camera: camPos.toArray(),
      breach: breach.position.toArray(),
      found: game.findTarget()?.id ?? null,
    };
  });

  console.log('  info objetivo:', JSON.stringify(target));

  // Avance determinista: 2 s de simulación sin depender del framerate.
  await page.evaluate(() => {
    const game = window.__orbital;
    for (let i = 0; i < 120; i++) game.update(1 / 60);
  });
  const aimed = await page.evaluate(() => {
    const game = window.__orbital;
    const breach = game.station.active[0];
    return {
      found: !!game.findTarget(),
      progress: breach ? breach.progress : 1,
      prompt: document.querySelector('#prompt-label').textContent,
    };
  });

  check('objetivo apuntado con el raycast', aimed.found, aimed.prompt);
  check('progreso de reparación avanza', aimed.progress > 0.05, String(aimed.progress));

  // El renderizado por software del CI va lento: acelerar el último tramo
  // para validar la finalización sin depender del framerate.
  await page.evaluate((id) => {
    const game = window.__orbital;
    const breach = game.station.points.find((point) => point.id === id);
    if (breach) breach.progress = 0.97;
    // 0.5 s de simulación: suficiente para cerrar el 3 % restante.
    for (let i = 0; i < 30; i++) game.update(1 / 60);
  }, target.id);

  const repaired = await page.evaluate(() => {
    const game = window.__orbital;
    game.controls.mouse.left = false;
    return {
      repaired: game.station.repairedCount,
      active: game.station.active.length,
      integrity: game.integrity,
      toast: document.querySelector('#toast').textContent,
    };
  });

  check('fuga reparada', repaired.repaired >= 1, String(repaired.repaired));
  check('integridad recompensada', repaired.integrity > 95, String(repaired.integrity));
  check('nueva fuga generada', repaired.active >= 2, String(repaired.active));

  // Escáner
  const scan = await page.evaluate(() => {
    const game = window.__orbital;
    game.selectTool(2);
    game.scanCooldown = 0;
    game.scan();
    return { reveal: game.revealUntil > game.time, cooldown: game.scanCooldown };
  });
  check('escáner activa la revelación', scan.reveal && scan.cooldown > 0);

  // Puerto de oxígeno
  await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(
      game.station.o2Port.x,
      game.station.o2Port.y,
      game.station.o2Port.z + 1.2
    );
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.player.o2 = 40;
    // 3 s de simulación: 20 %/s de recarga.
    for (let i = 0; i < 180; i++) game.update(1 / 60);
  });
  const refilled = await page.evaluate(() => window.__orbital.player.o2);
  check('el puerto recarga oxígeno', refilled > 50, `40 → ${refilled.toFixed(1)}`);

  // Movimiento con propulsores en espacio libre (dentro del radio del cable)
  const before = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, 6, 30);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.cameraRig.yaw = Math.PI;
    game.cameraRig.pitch = 0.12;
    game.cameraRig.distance = 6.2;
    game.cameraRig.targetDistance = 6.2;
    game.cameraRig.snap(game.player.group.position);
    return game.player.group.position.toArray();
  });
  await page.keyboard.down('KeyW');
  await page.keyboard.down('ShiftLeft');
  await page.evaluate(() => {
    const game = window.__orbital;
    // 1 s de simulación con los propulsores activos.
    for (let i = 0; i < 60; i++) game.update(1 / 60);
  });
  await page.keyboard.up('KeyW');
  await page.keyboard.up('ShiftLeft');
  const after = await page.evaluate(() => ({
    position: window.__orbital.player.group.position.toArray(),
    energy: window.__orbital.player.energy,
    o2: window.__orbital.player.o2,
  }));

  const moved = Math.hypot(
    after.position[0] - before[0],
    after.position[1] - before[1],
    after.position[2] - before[2]
  );
  check('los propulsores mueven al jugador', moved > 0.5, `Δ=${moved.toFixed(2)}m`);
  check('el propulsor consume energía', after.energy < 100, String(after.energy));

  // Recursos: O2 lento, casco sin desgaste por tiempo y RCS quieto.
  const resources = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, 6, 30);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.player.o2 = 100;
    game.player.hull = 100;
    game.player.energy = 50;
    for (let i = 0; i < 60; i++) game.update(1 / 60);
    return {
      o2: game.player.o2,
      hull: game.player.hull,
      energy: game.player.energy,
      safe: game.player.safe,
      difficulty: game.balance.id,
    };
  });
  check(
    'O2 se consume lentamente (Exploración)',
    !resources.safe && resources.o2 < 100 && resources.o2 > 99.5,
    JSON.stringify(resources)
  );
  check('el casco no pierde integridad por tiempo', resources.hull === 100, String(resources.hull));
  check('RCS no consume si no se propulsa', resources.energy === 50, String(resources.energy));

  // Cable: se tensa al superar la distancia máxima y frena al jugador.
  const tetherLimit = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, 0, 45);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    for (let i = 0; i < 300; i++) game.update(1 / 60);
    return {
      ...game.tether.status,
      position: game.player.group.position.toArray(),
    };
  });
  check(
    'el cable limita la distancia máxima',
    tetherLimit.active && tetherLimit.distance <= tetherLimit.max + 2,
    JSON.stringify(tetherLimit)
  );

  // Vista de EVA con el cable desplegado (captura de validación).
  await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, 0, 22);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.cameraRig.yaw = 0;
    game.cameraRig.pitch = 0.12;
    game.cameraRig.snap(game.player.group.position);
    for (let i = 0; i < 20; i++) game.update(1 / 60);
  });
  await page.screenshot({ path: `${SHOTS}/tether.png` });

  // Consola del puente: E abre el panel y permite activar una misión.
  const cockpit = await page.evaluate(() => {
    const game = window.__orbital;
    game.player.body.position.set(0, -8.8, -12.5);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.controls.interactPressed = true;
    game.update(1 / 60);
    return {
      panel: game.panelOpen,
      title: document.querySelector('#panel-title').textContent,
      mission: game.missions.active?.id ?? null,
    };
  });
  check('E abre la consola del puente', cockpit.panel === 'navigation', JSON.stringify(cockpit));
  await page.screenshot({ path: `${SHOTS}/panel.png` });

  const missionTest = await page.evaluate(() => {
    const game = window.__orbital;
    game.handlePanelAction('activate', 'engineering_power');
    game.closePanel();
    game.player.body.position.set(6.8, -8.8, -1.5);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.openPanel('engineering', 'engineering');

    for (let circuit = 0; circuit < 3; circuit++) {
      game.handlePanelAction('circuit', String(circuit));
      for (let i = 0; i < 190; i++) game.update(1 / 60);
    }

    const mission = game.missions.getById('engineering_power');
    return {
      circuits: game.engineering.circuits,
      power: game.interior.powerLevel,
      mission: mission.state,
      active: game.missions.activeId,
    };
  });
  check(
    'misión interior de ingeniería completable',
    missionTest.circuits.every(Boolean) && missionTest.mission === 'completed',
    JSON.stringify(missionTest)
  );
  check('los circuitos devuelven potencia al hábitat', missionTest.power > 0.99, String(missionTest.power));

  await page.evaluate(() => window.__orbital.closePanel());

  // Tarea exterior real: activar la misión de herramientas y recoger una.
  const exteriorTask = await page.evaluate(() => {
    const game = window.__orbital;
    game.missions.activate('tool_recovery');
    game.player.body.position.set(0, 4.8, 10.6);
    game.player.body.velocity.setZero();
    game.player.sync(0.016, game.camera);
    game.controls.interactPressed = true;
    game.update(1 / 60);
    for (let i = 0; i < 10; i++) game.update(1 / 60);

    const mission = game.missions.getById('tool_recovery');
    const task = game.exteriorTasks.tasks.find((item) => item.id === 'tool_1');
    return {
      done: task.done,
      progress: mission.objectives[0].progress,
      target: mission.objectives[0].target,
      tools: game.inventory.tools,
    };
  });
  check(
    'tarea EVA real completa y progresa la misión',
    exteriorTask.done && exteriorTask.progress === 1 && exteriorTask.tools === 1,
    JSON.stringify(exteriorTask)
  );

  // Pausa y reanudación
  await page.evaluate(() => window.__orbital.pause());
  const paused = await page.evaluate(() => ({
    state: window.__orbital.state,
    screen: !document.querySelector('#screen-pause').classList.contains('hidden'),
  }));
  check('pausa muestra su pantalla', paused.state === 'paused' && paused.screen);

  await page.evaluate(() => window.__orbital.resume());
  await sleep(300);
  check('reanudar vuelve a jugar', (await page.evaluate(() => window.__orbital.state)) === 'playing');

  // Victoria forzada (flujo de pantalla final)
  await page.evaluate(() => {
    const game = window.__orbital;
    game.station.repairedCount = game.station.totalBreaches;
    game.win();
  });
  await sleep(400);
  const won = await page.evaluate(() => ({
    state: window.__orbital.state,
    screen: !document.querySelector('#screen-win').classList.contains('hidden'),
    time: document.querySelector('#win-time').textContent,
  }));
  check('pantalla de victoria', won.state === 'won' && won.screen, won.time);

  await page.screenshot({ path: `${SHOTS}/win.png` });

  // Derrota por integridad del casco
  await page.evaluate(() => {
    const game = window.__orbital;
    game.start();
    game.player.hull = 0;
    game.update(1 / 60);
  });
  const lost = await page.evaluate(() => ({
    state: window.__orbital.state,
    screen: !document.querySelector('#screen-lose').classList.contains('hidden'),
    title: document.querySelector('#lose-title').textContent,
  }));
  check('pantalla de derrota', lost.state === 'lost' && lost.screen, lost.title);

  check('sin errores de consola', errors.length === 0, errors.join(' | '));

  console.log(`\n${failures === 0 ? 'Smoke test OK' : `${failures} fallo(s)`}`);
} catch (error) {
  failures++;
  console.error('Error en el smoke test:', error);
} finally {
  await browser?.close();
  server.kill();
  process.exit(failures === 0 ? 0 : 1);
}
